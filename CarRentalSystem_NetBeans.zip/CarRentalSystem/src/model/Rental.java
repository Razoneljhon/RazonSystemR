package model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Rental {
    private int id;
    private int carId;
    private String customerName;
    private String contact;
    private LocalDate startDate;
    private LocalDate endDate;
    private double dailyRate;
    private String status;

    public Rental(int id, int carId, String customerName, String contact,
                  LocalDate startDate, LocalDate endDate, double dailyRate, String status) {
        this.id = id;
        this.carId = carId;
        this.customerName = customerName;
        this.contact = contact;
        this.startDate = startDate;
        this.endDate = endDate;
        this.dailyRate = dailyRate;
        this.status = status;
    }

    public int getId() { return id; }
    public int getCarId() { return carId; }
    public String getCustomerName() { return customerName; }
    public String getContact() { return contact; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public double getDailyRate() { return dailyRate; }
    public String getStatus() { return status; }

    public long getDays() {
        long days = ChronoUnit.DAYS.between(startDate, endDate);
        return Math.max(1, days);
    }

    public double getTotal() { return getDays() * dailyRate; }
    public void setStatus(String status) { this.status = status; }
}
