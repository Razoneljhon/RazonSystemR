package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RentalManager {
    private final List<Rental> rentals = new ArrayList<>();
    private int nextId = 1;
    private final CarManager carManager;

    public RentalManager(CarManager carManager) {
        this.carManager = carManager;
    }

    public List<Rental> getAllRentals() {
        return Collections.unmodifiableList(rentals);
    }

    public Rental rentCar(int carId, String customer, String contact,
                          LocalDate start, LocalDate end) {
        Car car = carManager.findById(carId);
        if (car == null || !"Available".equals(car.getStatus())) {
            throw new IllegalArgumentException("Hindi available ang kotse na ito.");
        }
        if (customer.trim().isEmpty()) throw new IllegalArgumentException("Ilagay ang pangalan ng customer.");
        if (start == null || end == null || end.isBefore(start)) {
            throw new IllegalArgumentException("Hindi valid ang rental dates.");
        }
        Rental rental = new Rental(nextId++, carId, customer.trim(), contact.trim(),
                start, end, car.getDailyRate(), "Active");
        rentals.add(rental);
        car.setStatus("Rented");
        return rental;
    }

    public boolean returnCar(int rentalId) {
        for (Rental rental : rentals) {
            if (rental.getId() == rentalId && "Active".equals(rental.getStatus())) {
                rental.setStatus("Returned");
                Car car = carManager.findById(rental.getCarId());
                if (car != null) car.setStatus("Available");
                return true;
            }
        }
        return false;
    }
}
