package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CarManager {
    private final List<Car> cars = new ArrayList<>();
    private int nextId = 1;

    public CarManager() {
        addCar("Toyota", "Vios", 2022, 1800);
        addCar("Honda", "City", 2023, 2000);
        addCar("Mitsubishi", "Montero", 2021, 3500);
    }

    public Car addCar(String brand, String model, int year, double rate) {
        Car car = new Car(nextId++, brand, model, year, rate, "Available");
        cars.add(car);
        return car;
    }

    public List<Car> getAllCars() {
        return Collections.unmodifiableList(cars);
    }

    public Car findById(int id) {
        for (Car car : cars) if (car.getId() == id) return car;
        return null;
    }

    public boolean updateCar(int id, String brand, String model, int year, double rate) {
        Car car = findById(id);
        if (car == null) return false;
        car.setBrand(brand);
        car.setModel(model);
        car.setYear(year);
        car.setDailyRate(rate);
        return true;
    }

    public boolean deleteCar(int id) {
        Car car = findById(id);
        if (car == null || !"Available".equals(car.getStatus())) return false;
        return cars.remove(car);
    }
}
