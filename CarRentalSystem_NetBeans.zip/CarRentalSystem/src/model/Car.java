package model;

public class Car {
    private int id;
    private String brand;
    private String model;
    private int year;
    private double dailyRate;
    private String status;

    public Car(int id, String brand, String model, int year, double dailyRate, String status) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.dailyRate = dailyRate;
        this.status = status;
    }

    public int getId() { return id; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public int getYear() { return year; }
    public double getDailyRate() { return dailyRate; }
    public String getStatus() { return status; }

    public void setBrand(String brand) { this.brand = brand; }
    public void setModel(String model) { this.model = model; }
    public void setYear(int year) { this.year = year; }
    public void setDailyRate(double dailyRate) { this.dailyRate = dailyRate; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return id + " - " + brand + " " + model;
    }
}
