package controller;

import model.Rental;
import model.RentalManager;
import java.time.LocalDate;
import java.util.List;

public class RentalController {
    private final RentalManager manager;

    public RentalController(RentalManager manager) { this.manager = manager; }
    public List<Rental> getRentals() { return manager.getAllRentals(); }

    public Rental rentCar(int carId, String customer, String contact,
                          LocalDate start, LocalDate end) {
        return manager.rentCar(carId, customer, contact, start, end);
    }

    public boolean returnCar(int rentalId) { return manager.returnCar(rentalId); }
}
