package controller;

import model.Car;
import model.CarManager;
import java.util.List;

public class CarController {
    private final CarManager manager;

    public CarController(CarManager manager) { this.manager = manager; }

    public List<Car> getCars() { return manager.getAllCars(); }
    public Car findCar(int id) { return manager.findById(id); }
    public Car addCar(String brand, String model, int year, double rate) {
        validate(brand, model, year, rate);
        return manager.addCar(brand.trim(), model.trim(), year, rate);
    }
    public boolean updateCar(int id, String brand, String model, int year, double rate) {
        validate(brand, model, year, rate);
        return manager.updateCar(id, brand.trim(), model.trim(), year, rate);
    }
    public boolean deleteCar(int id) { return manager.deleteCar(id); }

    private void validate(String brand, String model, int year, double rate) {
        if (brand == null || brand.trim().isEmpty() || model == null || model.trim().isEmpty())
            throw new IllegalArgumentException("Ilagay ang brand at model ng kotse.");
        if (year < 1900 || year > 2100) throw new IllegalArgumentException("Hindi valid ang year.");
        if (rate <= 0) throw new IllegalArgumentException("Ang daily rate ay dapat higit sa zero.");
    }
}
