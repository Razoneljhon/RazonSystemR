package MainClass;

import javax.swing.SwingUtilities;
import view.MainUI;

public class MainClass {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainUI().setVisible(true));
    }
}
