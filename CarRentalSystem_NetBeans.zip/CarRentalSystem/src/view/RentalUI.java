package view;

import controller.CarController;
import controller.RentalController;
import model.Car;
import model.Rental;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class RentalUI extends JPanel {
    private final CarController carController;
    private final RentalController rentalController;
    private final Runnable refreshCars;
    private final JComboBox<Car> carCombo = new JComboBox<>();
    private final JTextField customerField = new JTextField(12);
    private final JTextField contactField = new JTextField(10);
    private final JTextField startField = new JTextField(LocalDate.now().toString(), 10);
    private final JTextField endField = new JTextField(LocalDate.now().plusDays(1).toString(), 10);
    private final RentalTableModel tableModel;
    private final JTable table;

    public RentalUI(CarController carController, RentalController rentalController, Runnable refreshCars) {
        this.carController = carController;
        this.rentalController = rentalController;
        this.refreshCars = refreshCars;
        setLayout(new BorderLayout(8, 8));

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        form.setBorder(BorderFactory.createTitledBorder("Create Rental"));
        form.add(new JLabel("Available Car:")); form.add(carCombo);
        form.add(new JLabel("Customer:")); form.add(customerField);
        form.add(new JLabel("Contact:")); form.add(contactField);
        form.add(new JLabel("Start (YYYY-MM-DD):")); form.add(startField);
        form.add(new JLabel("End (YYYY-MM-DD):")); form.add(endField);
        JButton rentButton = new JButton("Rent Car");
        JButton returnButton = new JButton("Return Selected");
        form.add(rentButton); form.add(returnButton);
        add(form, BorderLayout.NORTH);

        tableModel = new RentalTableModel(rentalController.getRentals());
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        add(new JScrollPane(table), BorderLayout.CENTER);

        rentButton.addActionListener(e -> createRental());
        returnButton.addActionListener(e -> returnRental());
        refresh();
    }

    public void refresh() {
        carCombo.removeAllItems();
        for (Car car : carController.getCars()) {
            if ("Available".equals(car.getStatus())) carCombo.addItem(car);
        }
        tableModel.setRentals(rentalController.getRentals());
    }

    private void createRental() {
        try {
            Car car = (Car) carCombo.getSelectedItem();
            if (car == null) throw new IllegalArgumentException("Walang available na kotse.");
            LocalDate start = LocalDate.parse(startField.getText().trim());
            LocalDate end = LocalDate.parse(endField.getText().trim());
            Rental rental = rentalController.rentCar(car.getId(), customerField.getText(),
                    contactField.getText(), start, end);
            refresh();
            if (refreshCars != null) refreshCars.run();
            JOptionPane.showMessageDialog(this,
                    "Rental created!\nRental ID: " + rental.getId()
                    + "\nDays: " + rental.getDays()
                    + "\nTotal: ₱" + String.format("%.2f", rental.getTotal()));
            customerField.setText("");
            contactField.setText("");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Rental Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void returnRental() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Pumili muna ng rental record."); return; }
        Rental rental = tableModel.getRentalAt(table.convertRowIndexToModel(row));
        if (rentalController.returnCar(rental.getId())) {
            refresh();
            if (refreshCars != null) refreshCars.run();
            JOptionPane.showMessageDialog(this, "Naibalik na ang kotse.");
        } else {
            JOptionPane.showMessageDialog(this, "Hindi active ang rental na ito.");
        }
    }
}
