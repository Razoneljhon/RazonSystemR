package view;

import controller.CarController;
import controller.RentalController;
import model.CarManager;
import model.RentalManager;
import javax.swing.*;
import java.awt.*;

public class MainUI extends JFrame {
    private final CarManager carManager;
    private final CarController carController;
    private final RentalManager rentalManager;
    private final RentalController rentalController;
    private CarUI carUI;
    private RentalUI rentalUI;

    public MainUI() {
        carManager = new CarManager();
        carController = new CarController(carManager);
        rentalManager = new RentalManager(carManager);
        rentalController = new RentalController(rentalManager);

        setTitle("Car Rental System");
        setSize(1150, 650);
        setMinimumSize(new Dimension(900, 500));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel title = new JLabel("CAR RENTAL SYSTEM", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        add(title, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        carUI = new CarUI(carController, () -> {
            if (rentalUI != null) rentalUI.refresh();
        });
        rentalUI = new RentalUI(carController, rentalController, () -> carUI.refresh());
        tabs.addTab("Car Management", carUI);
        tabs.addTab("Rental Management", rentalUI);
        add(tabs, BorderLayout.CENTER);

        JLabel footer = new JLabel("Manage cars, rentals, returns, and rental fees",
                SwingConstants.CENTER);
        footer.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        add(footer, BorderLayout.SOUTH);
    }
}
