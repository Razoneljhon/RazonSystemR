package view;

import controller.CarController;
import model.Car;
import javax.swing.*;
import java.awt.*;

public class CarUI extends JPanel {
    private final CarController controller;
    private final Runnable refreshRentals;
    private final JTextField brandField = new JTextField(10);
    private final JTextField modelField = new JTextField(10);
    private final JTextField yearField = new JTextField(5);
    private final JTextField rateField = new JTextField(7);
    private final CarTableModel tableModel;
    private final JTable table;

    public CarUI(CarController controller, Runnable refreshRentals) {
        this.controller = controller;
        this.refreshRentals = refreshRentals;
        setLayout(new BorderLayout(8, 8));

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        form.setBorder(BorderFactory.createTitledBorder("Car Details"));
        form.add(new JLabel("Brand:")); form.add(brandField);
        form.add(new JLabel("Model:")); form.add(modelField);
        form.add(new JLabel("Year:")); form.add(yearField);
        form.add(new JLabel("Daily Rate:")); form.add(rateField);

        JButton add = new JButton("Add Car");
        JButton update = new JButton("Update Selected");
        JButton delete = new JButton("Delete Selected");
        JButton clear = new JButton("Clear");
        form.add(add); form.add(update); form.add(delete); form.add(clear);
        add(form, BorderLayout.NORTH);

        tableModel = new CarTableModel(controller.getCars());
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        add(new JScrollPane(table), BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) loadSelectedCar();
        });
        add.addActionListener(e -> performAdd());
        update.addActionListener(e -> performUpdate());
        delete.addActionListener(e -> performDelete());
        clear.addActionListener(e -> clearFields());
        refresh();
    }

    public void refresh() {
        tableModel.setCars(controller.getCars());
        if (refreshRentals != null) refreshRentals.run();
    }

    private void loadSelectedCar() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        Car car = tableModel.getCarAt(table.convertRowIndexToModel(row));
        brandField.setText(car.getBrand());
        modelField.setText(car.getModel());
        yearField.setText(String.valueOf(car.getYear()));
        rateField.setText(String.valueOf(car.getDailyRate()));
    }

    private void performAdd() {
        try {
            controller.addCar(brandField.getText(), modelField.getText(),
                    Integer.parseInt(yearField.getText().trim()),
                    Double.parseDouble(rateField.getText().trim()));
            refresh(); clearFields();
        } catch (Exception ex) { showError(ex); }
    }

    private void performUpdate() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Pumili muna ng kotse sa table."); return; }
        try {
            Car car = tableModel.getCarAt(table.convertRowIndexToModel(row));
            if (!controller.updateCar(car.getId(), brandField.getText(), modelField.getText(),
                    Integer.parseInt(yearField.getText().trim()),
                    Double.parseDouble(rateField.getText().trim()))) {
                JOptionPane.showMessageDialog(this, "Hindi ma-update ang kotse.");
            }
            refresh();
        } catch (Exception ex) { showError(ex); }
    }

    private void performDelete() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Pumili muna ng kotse sa table."); return; }
        Car car = tableModel.getCarAt(table.convertRowIndexToModel(row));
        int confirm = JOptionPane.showConfirmDialog(this,
                "Burahin ang " + car + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (!controller.deleteCar(car.getId()))
                JOptionPane.showMessageDialog(this, "Hindi puwedeng burahin ang kotse na kasalukuyang rented.");
            refresh(); clearFields();
        }
    }

    private void clearFields() {
        brandField.setText(""); modelField.setText(""); yearField.setText(""); rateField.setText("");
        table.clearSelection();
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Invalid Input", JOptionPane.ERROR_MESSAGE);
    }
}
