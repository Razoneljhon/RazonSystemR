package view;

import model.Rental;
import javax.swing.table.AbstractTableModel;
import java.util.List;

public class RentalTableModel extends AbstractTableModel {
    private final String[] columns = {"Rental ID", "Car ID", "Customer", "Contact",
            "Start Date", "End Date", "Days", "Total (₱)", "Status"};
    private List<Rental> rentals;

    public RentalTableModel(List<Rental> rentals) { this.rentals = rentals; }
    public void setRentals(List<Rental> rentals) { this.rentals = rentals; fireTableDataChanged(); }
    public Rental getRentalAt(int row) { return rentals.get(row); }
    @Override public int getRowCount() { return rentals.size(); }
    @Override public int getColumnCount() { return columns.length; }
    @Override public String getColumnName(int col) { return columns[col]; }

    @Override
    public Object getValueAt(int row, int col) {
        Rental r = rentals.get(row);
        switch (col) {
            case 0: return r.getId();
            case 1: return r.getCarId();
            case 2: return r.getCustomerName();
            case 3: return r.getContact();
            case 4: return r.getStartDate();
            case 5: return r.getEndDate();
            case 6: return r.getDays();
            case 7: return String.format("%.2f", r.getTotal());
            case 8: return r.getStatus();
            default: return "";
        }
    }
}
