package view;

import model.Car;
import javax.swing.table.AbstractTableModel;
import java.util.List;

public class CarTableModel extends AbstractTableModel {
    private final String[] columns = {"ID", "Brand", "Model", "Year", "Daily Rate (₱)", "Status"};
    private List<Car> cars;

    public CarTableModel(List<Car> cars) { this.cars = cars; }
    public void setCars(List<Car> cars) { this.cars = cars; fireTableDataChanged(); }
    public Car getCarAt(int row) { return cars.get(row); }
    @Override public int getRowCount() { return cars.size(); }
    @Override public int getColumnCount() { return columns.length; }
    @Override public String getColumnName(int col) { return columns[col]; }

    @Override
    public Object getValueAt(int row, int col) {
        Car c = cars.get(row);
        switch (col) {
            case 0: return c.getId();
            case 1: return c.getBrand();
            case 2: return c.getModel();
            case 3: return c.getYear();
            case 4: return String.format("%.2f", c.getDailyRate());
            case 5: return c.getStatus();
            default: return "";
        }
    }
}
