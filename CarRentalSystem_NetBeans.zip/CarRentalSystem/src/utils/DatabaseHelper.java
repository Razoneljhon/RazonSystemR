package utils;

/*
 * Starter version: walang external database dependency.
 * Ang records ay nasa memory lamang at mawawala kapag isinara ang app.
 *
 * Kapag handa ka nang gumamit ng MySQL, dito natin ilalagay ang JDBC
 * connection at SQL initialization. Hindi kailangan ng database para
 * ma-run ang starter version na ito.
 */
public final class DatabaseHelper {
    private DatabaseHelper() { }

    public static boolean isDatabaseConfigured() {
        return false;
    }
}
