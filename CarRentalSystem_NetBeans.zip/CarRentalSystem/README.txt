CAR RENTAL SYSTEM - NETBEANS (JAVA SWING, CODE-ONLY UI)

FEATURES
- Car Management: Add, Update, Delete, and view cars.
- Rental Management: Rent an available car, calculate rental days/total fee, and return a car.
- Java Swing interface is created in code. No drag-and-drop or .form files are needed.
- Sample cars are added on startup.

HOW TO USE IN NETBEANS
1. Create a Java Application project named CarRentalSystem.
2. Under Source Packages, create packages:
   MainClass, controller, model, utils, view
3. Copy each .java file from this package structure into its matching package.
   The source files are inside the "src" folder in this ZIP.
4. Set the Main Class to MainClass.MainClass:
   Project Properties > Run > Main Class.
5. Run the project.

IMPORTANT
- This starter version stores records in memory only. All added cars/rentals are lost
  when you close the app. DatabaseHelper is a placeholder for a future MySQL connection.
- No CarUI.form or MainUI.form is required because the interface is coded manually.
- Requires a standard JDK (Java 8 or newer; Java 8 supports the APIs used here).
